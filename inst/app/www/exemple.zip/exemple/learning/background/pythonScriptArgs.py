#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# @package template.py
# @author Sebastien Ravel

"""
	The tamplate script
	====================
	:author: Sebastien Ravel
	:contact: sebastien.ravel@cirad.fr
	:date: 08/07/2016
	:version: 0.1

	Script description
	------------------

	This Programme run job array to lunch raxml

	Example
	-------

	>>> tamplate.py -f NT_ALIGN/ -o ./

	Help Programm
	-------------

	optional arguments:
		- \-h, --help
						show this help message and exit
		- \-v, --version
						display tamplate.py version number and exit

	Input mandatory infos for running:
		- \-f <path/to/directory/fasta>, --fasta <path/to/directory/fasta>
						path to fasta files
		- \-o <path/to/directory>, --out <path/to/directory>
						Name of output file directory

	Input infos for running with default values:
		- \-t <int>, --thread <int>
						number of threads for raxml (default = 4)
		- \-b <int>, --bootstrap <int>
						number of nbBootstrap for raxml (default = 100)
		- \-ro [<string> [<string> ...]], --raxmloption [<string> [<string> ...]]
						Other raxml options (default = "-f a -m GTRGAMMA -x 2 -p 2")
		- \-j <int>, --nbjob <int>
						Number of job array lunch (default = 100)

"""


##################################################
## Modules
##################################################
#Import MODULES_SEB
import sys, os, shutil
current_dir = os.path.dirname(os.path.abspath(__file__))+"/"
sys.path.insert(1,current_dir+'../modules/')
from MODULES_SEB import directory, printCol
## Python modules
import argparse
from time import localtime, strftime

## BIO Python modules

##################################################
## Variables Globales
version="0.1"
VERSION_DATE='16/06/2016'

##################################################
## Functions

###################################################
## Main code
##################################################
if __name__ == "__main__":

	# Initializations
	start_time = strftime("%d-%m-%Y_%H:%M:%S", localtime())
	# Parameters recovery
	parser = argparse.ArgumentParser(prog='tamplate.py', description='''This Programme run job array to lunch raxml''')
	parser.add_argument('-v', '--version', action='version', version='You are using %(prog)s version: ' + version, help=\
						'display tamplate.py version number and exit')
	parser.add_argument('-dd', '--debug',choices=("False","True"), dest='debug', help='enter verbose/debug mode', default = "False")

	filesReq = parser.add_argument_group('Input mandatory infos for running')
	filesReq.add_argument('-f', '--fasta', metavar="<path/to/directory/fasta>", type=directory, required=True, dest = 'fastaFileDir', help = 'path to fasta files')
	filesReq.add_argument('-o', '--out', metavar="<path/to/directory>", type = directory, required=True, dest = 'pathOut', help = 'Name of output file directory')

	files = parser.add_argument_group('Input infos for running with default values')
	files.add_argument('-t', '--thread', metavar="<int>",type = int, default=4, required=False, dest = 'nbThreads', help = 'number of threads for raxml (default = 4)')
	files.add_argument('-b', '--bootstrap', metavar="<int>",type = int, default=100, required=False, dest = 'nbBootstrap', help = 'number of nbBootstrap for raxml (default = 100)')
	files.add_argument('-ro', '--raxmloption', metavar="<string>", nargs='*', default=["-f a","-m GTRGAMMA","-x 2","-p 2"],required=False, dest = 'raxmlOptionValue', help = 'Other raxml options (default = "-f a -m GTRGAMMA -x 2 -p 2")')
	files.add_argument('-j', '--nbjob', metavar="<int>", type = int, default=100,required=False, dest = 'nbJobValue', help = 'Number of job array lunch (default = 100)')


	# Check parameters
	args = parser.parse_args()

	#Welcome message
	print("#################################################################")
	print("#              Welcome in tamplate (Version " + version + ")               #")
	print("#################################################################")
	print('Start time: ', start_time,'\n')

	# Récupère les arguments
	pathFastaFile = args.fastaFileDir
	pathFileOut = args.pathOut

	# defaults option
	nbThreads=args.nbThreads
	nbBootstrap=args.nbBootstrap
	raxmlOptionValue=" ".join(args.raxmlOptionValue)

	outputraxmlResDir = pathFileOut.pathDirectory+"raxmlRes/"
	outputSHDir = pathFileOut.pathDirectory+"sh/"
	outputTrashDir = pathFileOut.pathDirectory+"trash/"
	SGENameFile = outputSHDir+"submitQsubraxml.sge"


	# resume value to user
	print(" - Intput Info:")
	print("\t - Working in directory: %s" % pathFileOut.pathDirectory)
	print("\t - Fasta were in directory: %s" % pathFastaFile.pathDirectory)
	print("\t - Number of threads: %s" % nbThreads)
	print("\t - Number of nbBootstrap: %s" % nbBootstrap)
	print("\t - Other options are: %s" % raxmlOptionValue)

	print(" - Output Info:")
	print("\t - Output with result raxml were in directory: %s" % outputraxmlResDir)
	print("\t - Output sh were in directory: %s" % outputSHDir)
	print("\t - Output trash were in directory: %s\n\n" % outputTrashDir)





	print("\n - Execution summary:")

	print("\n  You want run Mutilraxml for %s fasta,\
 The script are created all fasta-Mutilraxml.sh for all fasta into %s,\n\
 For run all sub-script in qsub, %s was created.\n\
 It lunch programm with job array and run %s job max:\n" %(count-1,outputSHDir,SGENameFile, args.nbJobValue))
	printCol.green("\tqsub %s" % SGENameFile)
	print("\nStop time: ", strftime("%d-%m-%Y_%H:%M:%S", localtime()))
	print("#################################################################")
	print("#                        End of execution                       #")
	print("#################################################################")
